<!-- MENU -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>
                    <a href="./index.php" class="navbar-brand">S S B H J</a>
               </div>


               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="./index.php" class="smoothScroll">Home</a></li>
                         <li><a href="./about.php" class="smoothScroll">About</a></li>
                         <li><a href="./team.php" class="smoothScroll">Our Teachers</a></li>
                         <li><a href="./courses.php" class="smoothScroll">Courses</a></li>
                         <li><a href="./testimonial.php" class="smoothScroll">Reviews</a></li>
                         <li><a href="./contact.php" class="smoothScroll">Contact</a></li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="tel:+917058402300"><i class="fa fa-phone"></i> +91 7058402300</a></li>
                         <li><a href="./dashboard"><i class="fa fa-lock"></i>Admin</a></li>
                    </ul>
               </div>

          </div>
     </section>