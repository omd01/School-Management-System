<?php
$conn = mysqli_connect("localhost","root","","school") or die("Connection was not established");
?>